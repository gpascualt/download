#!/bin/bash

#VARIABLES
#Indique el nombre de la institución.
INSTITUCION=Cedimed
#A continuación indique las fechas a migrar. Es posible colocar una fecha única, o una fecha de inicio y otra de fin separadas por un guion.
MigratingDay=20170721-20170731
#Indique la carpeta en la que se encuentran los ejecutables findscu y movescu del aplicativo dcmtools.
PATH_DCMTOOLS=/PACS/dcmtools/bin
#Indique la carpeta en la que se desea almacenar la lista de estudios a consultar y migrar, asi como el log de errores.
PATH_MIGRATION=/home/oracl/migracion/
#Indique los datos DICOM del PACS de origen.
DCMDATA_VENDOR=cedFIR@172.30.16.123:2104
#Indique el AET del PACS de destino. Es importante que este nodo esté registrado en los Application Entities del PACS de origen.
DCMDATA_HIRUKO=CEDHRK2
#Indique el timeout para el comando movescu, que dependerá de la velocidad de red entre servidores origen-destino, y la compresión de los estudios.
TIMEOUT=3600
#Indique los correos electronicos a los cuales desea que llegue la notificacion cuando el script finalice.
MAIL=soporte@imexhs.com
MAIL2=support@imexhs.com
#SCRIPT
#En la siguiente sección se encuentra el código que se ejecuta durante el script. IMPORTANTE: Modificar o quitar el filtro -mModalitiesInStudy dependiendo de la necesidad.
mkdir -p $PATH_MIGRATION/$MigratingDay
$PATH_DCMTOOLS/./findscu -c $DCMDATA_VENDOR -mStudyDate=$MigratingDay -mModalitiesInStudy=CR -r0020000D -out-dir $PATH_MIGRATION/$MigratingDay
cd $PATH_MIGRATION/$MigratingDay/
StudiesNum=$(ls | wc -l)
touch $PATH_MIGRATION/$MigratingDay/log
echo "CANTIDAD DE ESTUDIOS: " $StudiesNum
for (( i=1; i<=$StudiesNum; i++ ))
do
        if [ $i -lt 10 ]
        then
                echo "----------------STUDY INSTANCE UID:----------------"
                cat $PATH_MIGRATION/$MigratingDay/00$i.dcm
                timeout $TIMEOUT $PATH_DCMTOOLS/./movescu -c $DCMDATA_VENDOR --dest $DCMDATA_HIRUKO $PATH_MIGRATION/$MigratingDay/00$i.dcm
                if [ $? -ne 0 ];
                then
                        echo 00$i.dcm >> $PATH_MIGRATION/$MigratingDay/log
                fi
                echo "\n"
                echo "$i"
                sleep 1
        elif [ $i -lt 100 ]
        then
                echo "----------------STUDY INSTANCE UID:----------------"
                cat $PATH_MIGRATION/$MigratingDay/0$i.dcm
                timeout $TIMEOUT $PATH_DCMTOOLS/./movescu -c $DCMDATA_VENDOR --dest $DCMDATA_HIRUKO $PATH_MIGRATION/$MigratingDay/0$i.dcm
                if [ $? -ne 0 ];
                then
                        echo 0$i.dcm >> $PATH_MIGRATION/$MigratingDay/log
                fi
                echo "\n"
                echo "$i"
                sleep 1
        else
                echo "----------------STUDY INSTANCE UID:----------------"
                cat $PATH_MIGRATION/$MigratingDay/$i.dcm
                timeout $TIMEOUT $PATH_DCMTOOLS/./movescu -c $DCMDATA_VENDOR --dest $DCMDATA_HIRUKO $PATH_MIGRATION/$MigratingDay/$i.dcm
                if [ $? -ne 0 ];
                then
                        echo $i.dcm >> $PATH_MIGRATION/$MigratingDay/log
                fi
                echo "\n"
                echo "$i"
                sleep 1
        fi
done
echo "Se ha terminado de ejecutar el script de migracion para "$MigratingDay" en "$PATH_MIGRATION"." | mail -s "Migracion "$INSTITUCION" - Script finalizado" $MAIL $MAIL2
